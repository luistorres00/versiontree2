// Definir o IP/URL para onde enviar os dados atualizados
// IP config casa
// const url = "http://192.168.1.148:16082/upData";
// IP config WFR
const url = "http://192.168.1.148:16082";
// IP CORRIDAS
// const url = "http://192.168.1.XYZ:16082/upData";

module.exports = url;
